module com.karla.gastosemanal {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.karla.gastosemanal to javafx.fxml;
    exports com.karla.gastosemanal;
}
