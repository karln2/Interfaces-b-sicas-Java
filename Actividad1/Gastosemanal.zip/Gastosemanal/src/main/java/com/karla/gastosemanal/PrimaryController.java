package com.karla.gastosemanal;

import javafx.fxml.FXML;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML
    private TextField GastAli;
    @FXML
    private TextField GastRefr;
    @FXML
    private TextField GastT;
    @FXML
    private TextField GastTl;
    @FXML
    private TextField GastO;
    
    @FXML
    private TextField TS;
    @FXML
    private TextField GA;

    @FXML
    private void Calcular() {
        try {
            double alimentacion = leerValor(GastAli);
            double refrigerios = leerValor(GastRefr);
            double transporte = leerValor(GastT);
            double telefonia = leerValor(GastTl);
            double otros = leerValor(GastO);

            // Calcula el total semanal
            double total = alimentacion + refrigerios + transporte + telefonia + otros;
            TS.setText(String.valueOf(total));

            // Determina cuál fue el gasto más alto
            double max = alimentacion;
            String categoriaMax = "Alimentación";

            if (refrigerios > max) { 
                max = refrigerios; 
                categoriaMax = "Refrigerios"; 
            }
            if (transporte > max) { 
                max = transporte; 
                categoriaMax = "Transporte"; 
            }
            if (telefonia > max) { 
                max = telefonia; 
                categoriaMax = "Telefonía"; 
            }
            if (otros > max) { 
                max = otros; 
                categoriaMax = "Otros"; 
            }

            GA.setText(categoriaMax);

        } catch (NumberFormatException e) {
            TS.setText("Error en datos");
            GA.setText("Revisa números");
        }
    }

    private double leerValor(TextField txt) {
        String texto = txt.getText();
        if (texto == null || texto.trim().isEmpty()) {
            return 0.0;
        }
        return Double.parseDouble(texto.trim());
    }

    @FXML
    private void Limpiar() {
        GastAli.clear();
        GastRefr.clear();
        GastT.clear();
        GastTl.clear();
        GastO.clear();
        TS.clear();
        GA.clear();
    }
}