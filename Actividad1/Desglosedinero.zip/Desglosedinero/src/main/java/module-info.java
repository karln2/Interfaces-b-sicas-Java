module com.karla.desglosedinero {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.karla.desglosedinero to javafx.fxml;
    exports com.karla.desglosedinero;
}
