package com.karla.desglosedinero;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML private TextField Money;
    @FXML private ListView<String> di;
    @FXML private ListView<String> b;

    @FXML
    private void Desglosar() {
        try {
            String texto = Money.getText();
            if (texto == null || texto.trim().isEmpty()) {
                return;
            }

            int dinero = Integer.parseInt(texto.trim());

            // Cálculos con divisiones enteras y residuos
            int b500 = dinero / 500; dinero %= 500;
            int b200 = dinero / 200; dinero %= 200;
            int b100 = dinero / 100; dinero %= 100;
            int b50  = dinero / 50;  dinero %= 50;
            int b20  = dinero / 20;  dinero %= 20;
            int m10  = dinero / 10;  dinero %= 10;
            int m5   = dinero / 5;   dinero %= 5;
            int m2   = dinero / 2;   dinero %= 2;
            int m1   = dinero;

            // Llena la lista izquierda con las denominaciones hacia abajo
            di.getItems().clear();
            di.getItems().addAll(
                "Billetes de $500",
                "Billetes de $200",
                "Billetes de $100",
                "Billetes de $50",
                "Billetes de $20",
                "Monedas de $10",
                "Monedas de $5",
                "Monedas de $2",
                "Monedas de $1"
            );

            // Llena la lista derecha con las cantidades hacia abajo
            b.getItems().clear();
            b.getItems().addAll(
                String.valueOf(b500),
                String.valueOf(b200),
                String.valueOf(b100),
                String.valueOf(b50),
                String.valueOf(b20),
                String.valueOf(m10),
                String.valueOf(m5),
                String.valueOf(m2),
                String.valueOf(m1)
            );

        } catch (NumberFormatException e) {
            di.getItems().clear();
            di.getItems().add("Error");
            b.getItems().clear();
        }
    }

    @FXML
    private void Borrar() {
        Money.clear();
        di.getItems().clear();
        b.getItems().clear();
    }
}