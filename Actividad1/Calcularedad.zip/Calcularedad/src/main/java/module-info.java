module com.karla.calcularedad {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.karla.calcularedad to javafx.fxml;
    exports com.karla.calcularedad;
}
