package com.karla.edad;

import com.karla.calcularedad.App;

public class Main {
    public static void main(String[] args) {
        App.main(args);
    }
}