package com.karla.calcularedad;

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class PrimaryController {

    @FXML
    private TextField txtFechaNacimiento;

    @FXML
    private Label lblTienes;

    @FXML
    private void Calcular() {
        String textoFecha = txtFechaNacimiento.getText();
        
        if (textoFecha == null || textoFecha.trim().isEmpty()) {
            lblTienes.setText("Por favor ingresa una fecha.");
            return;
        }

        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate fechaNac = LocalDate.parse(textoFecha.trim(), formatter);
            LocalDate hoy = LocalDate.now();

            if (fechaNac.isAfter(hoy)) {
                lblTienes.setText("La fecha no puede ser futura,debido a que no existes");
                return;
            }

            Period periodo = Period.between(fechaNac, hoy);
            int anios = periodo.getYears();
            int meses = periodo.getMonths();

            lblTienes.setText("Tiene " + anios + " años con " + meses + " meses");

        } catch (DateTimeParseException e) {
            lblTienes.setText("Formato inválido. Usa dd/mm/aaaa");
        }
    }

    @FXML
    private void Limpiar() {
        txtFechaNacimiento.clear();
        lblTienes.setText("");
    }
}