module com.karla.cifrasydivisiones {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.karla.cifrasydivisiones to javafx.fxml;
    exports com.karla.cifrasydivisiones;
}
