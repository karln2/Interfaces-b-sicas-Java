package com.karla.cifrasydivisiones;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;

public class PrimaryController {

    @FXML private TextField txtNumero;
    @FXML private TextField num;
    @FXML private TextField ci;
    @FXML private TextField pa;
    @FXML private TextField total;
    @FXML private TextField mayor;
    @FXML private TextField menor;
    @FXML private ListView<String> listDivisores;

    @FXML
    private void Analizar() {
        try {
            String texto = txtNumero.getText().trim();
            if (texto.isEmpty()) return;

            int n = Integer.parseInt(texto);
            int temp = Math.abs(n);

            int cantidadCifras = 0;
            int sumaImpares = 0;
            int sumaPares = 0;
            int sumaTotal = 0;
            int cifraMayor = -1;
            int cifraMenor = 10;

            if (temp == 0) {
                cantidadCifras = 1;
                cifraMayor = 0;
                cifraMenor = 0;
            } else {
                while (temp > 0) {
                    int digito = temp % 10;
                    cantidadCifras++;
                    sumaTotal += digito;

                    if (digito % 2 == 0) {
                        sumaPares += digito;
                    } else {
                        sumaImpares += digito;
                    }

                    if (digito > cifraMayor) cifraMayor = digito;
                    if (digito < cifraMenor) cifraMenor = digito;

                    temp /= 10;
                }
            }

            num.setText(String.valueOf(cantidadCifras));
            ci.setText(String.valueOf(sumaImpares));
            pa.setText(String.valueOf(sumaPares));
            total.setText(String.valueOf(sumaTotal));
            mayor.setText(String.valueOf(cifraMayor));
            menor.setText(String.valueOf(cifraMenor));

            listDivisores.getItems().clear();
            int nAbs = Math.abs(n);
            if (nAbs == 0) {
                listDivisores.getItems().add("Infinitos");
            } else {
                for (int i = 1; i <= nAbs; i++) {
                    if (nAbs % i == 0) {
                        listDivisores.getItems().add(String.valueOf(i));
                    }
                }
            }

        } catch (NumberFormatException e) {
            num.setText("Error");
        }
    }

    @FXML
    private void Limpiar() {
        txtNumero.clear();
        num.clear();
        ci.clear();
        pa.clear();
        total.clear();
        mayor.clear();
        menor.clear();
        listDivisores.getItems().clear();
    }
}
